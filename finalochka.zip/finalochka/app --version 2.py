import os
print(os.urandom(24))
